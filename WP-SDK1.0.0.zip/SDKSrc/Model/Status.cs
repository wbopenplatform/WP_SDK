﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TencentWeiboSDK.Deserializer;
using System.Collections;

namespace TencentWeiboSDK.Model
{
    /// <summary>
    /// 微博的 Model, 用于表示微博的对象.
    /// </summary>
    public class Status : BaseModel
    {
        private string id = string.Empty;
        private string text = string.Empty;
        private int timestamp = 0;
        private string origtext = string.Empty;
        private int count = 0;
        private int mcount =0;
        private Status source = null;
        private string emotiontype = string.Empty;
        private string emotionurl = string.Empty;
        private int status = 0;
        private string geo = string.Empty;
        private int isvip = 0;
        private string location = string.Empty;
        private string head = string.Empty;
        private int type = 0;
        private bool self = false;
        private string nick = string.Empty;
        private string openid = string.Empty;
        private string name = string.Empty;
        private IList image = null;
        private string fromurl;
        

        /// <summary>
        /// 构造函数
        /// </summary>
        public Status()
        { }

        /// <summary>
        /// 微博内容
        /// </summary>
        public string Text
        {
            get
            {
                return text;
            }
            set
            {
                if (value != text)
                {
                    text = value;
                    NotifyPropertyChanged("Text");
                }
            }
        }

        /// <summary>
        /// 原始内容
        /// </summary>
        public string Origtext
        {
            get
            {
                return origtext;
            }
            set
            {
                if (value != origtext)
                {
                    origtext = value;
                    NotifyPropertyChanged("Origtext");
                }
            }
        }

        /// <summary>
        /// 微博被转次数
        /// </summary>
        public int Count
        {
            get
            {
                return count;
            }
            set
            {
                if (value != count)
                {
                    count = value;
                    NotifyPropertyChanged("Count");
                }
            }
        }

        /// <summary>
        /// 点评次数
        /// </summary>
        public int MCount
        {
            get
            {
                return mcount;
            }
            set
            {
                if (value != mcount)
                {
                    mcount = value;
                    NotifyPropertyChanged("MCount");
                }
            }
        }

        private string from;
        /// <summary>
        /// 来源
        /// </summary>
        public string From
        {
            get
            {
                return from;
            }
            set
            {
                if (value != from)
                {
                    from = value;
                    NotifyPropertyChanged("From");
                }
            }
        }


        /// <summary>
        /// 来源url
        /// </summary>
        public string FromUrl
        {
            get
            {
                return fromurl;
            }
            set
            {
                if (value != fromurl)
                {
                    fromurl = value;
                    NotifyPropertyChanged("FromUrl");
                }
            }
        }

        /// <summary>
        /// 微博唯一id
        /// </summary>
        public string Id
        {
            get
            {
                return id;
            }
            set
            {
                if (value != id)
                {
                    id = value;
                    NotifyPropertyChanged("Id");
                }
            }
        }

        /// <summary>
        /// 图片url列表
        /// </summary>
        public IList Image
        {
            get
            {
                return image;
            }
            set
            {
                if (value != image)
                {
                    image = value;
                    NotifyPropertyChanged("Image");
                }
            }
        }

        /// <summary>
        /// 发表人帐户名
        /// </summary>
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                if (value != name)
                {
                    name = value;
                    NotifyPropertyChanged("Name");
                }
            }
        }

        /// <summary>
        /// 用户唯一id，与name相对应
        /// </summary>
        public string OpenId
        {
            get
            {
                return openid;
            }
            set
            {
                if (value != openid)
                {
                    openid = value;
                    NotifyPropertyChanged("OpenId");
                }
            }
        }

        /// <summary>
        /// 发表人昵称
        /// </summary>
        public string Nick
        {
            get
            {
                return nick;
            }
            set
            {
                if (value != nick)
                {
                    nick = value;
                    NotifyPropertyChanged("Nick");
                }
            }
        }

        /// <summary>
        /// 是否自已发的的微博
        /// </summary>
        public bool Self
        {
            get
            {
                return self;
            }
            set
            {
                if (value != self)
                {
                    self = value;
                    NotifyPropertyChanged("Self");
                }
            }
        }

        /// <summary>
        /// 发表时间
        /// </summary>
        public int Timestamp
        {
            get
            {
                return timestamp;
            }
            set
            {
                if (value != timestamp)
                {
                    timestamp = value;
                    NotifyPropertyChanged("Timestamp");
                }
            }
        }

        /// <summary>
        /// 微博类型，1-原创发表，2-转载，3-私信，4-回复，5-空回，6-提及，7-评论
        /// </summary>
        public int Type
        {
            get
            {
                return type;
            }
            set
            {
                if (value != type)
                {
                    type = value;
                    NotifyPropertyChanged("Type");
                }
            }
        }

        /// <summary>
        /// 发表者头像url
        /// </summary>
        public string Head
        {
            get
            {
                return head;
            }
            set
            {
                if (value != head)
                {
                    head = value;

                    if (!string.IsNullOrEmpty(head))
                    {
                        head += @"/50";
                    }

                    NotifyPropertyChanged("Head");
                }
            }
        }

        /// <summary>
        /// 发表者所在地
        /// </summary>
        public string Location
        {
            get
            {
                return location;
            }
            set
            {
                if (value != location)
                {
                    location = value;
                    NotifyPropertyChanged("Location");
                }
            }
        }

        
        /// <summary>
        /// 是否微博认证用户，0-不是，1-是
        /// </summary>
        public int Isvip
        {
            get
            {
                return isvip;
            }
            set
            {
                if (value != isvip)
                {
                    isvip = value;
                    NotifyPropertyChanged("Isvip");
                }
            }
        }

        /// <summary>
        /// 发表者地理信息
        /// </summary>
        public string Geo
        {
            get
            {
                return geo;
            }
            set
            {
                if (value != geo)
                {
                    geo = value;
                    NotifyPropertyChanged("Geo");
                }
            }
        }

        
        /// <summary>
        /// 微博状态，0-正常，1-系统删除，2-审核中，3-用户删除，4-根删除
        /// </summary>
        public int State
        {
            get
            {
                return status;
            }
            set
            {
                if (value != status)
                {
                    status = value;
                    NotifyPropertyChanged("State");
                }
            }
        }

        /// <summary>
        /// 心情图片url
        /// </summary>
        public string Emotionurl
        {
            get
            {
                return emotionurl;
            }
            set
            {
                if (value != emotionurl)
                {
                    emotionurl = value;
                    NotifyPropertyChanged("Emotionurl");
                }
            }
        }

        /// <summary>
        /// 心情类型
        /// </summary>
        public string EmotionType
        {
            get
            {
                return emotiontype;
            }
            set
            {
                if (value != emotiontype)
                {
                    emotiontype = value;
                    NotifyPropertyChanged("EmotionType");
                }
            }
        }

        /// <summary>
        /// 当type=2时，source即为源tweet
        /// </summary>
        public Status Source
        {
            get
            {
                return source;
            }
            set
            {
                if (value != source)
                {
                    source = value;
                    NotifyPropertyChanged("Source");
                }
            }
        }
    }
}
