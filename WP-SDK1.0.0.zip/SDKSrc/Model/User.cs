﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace TencentWeiboSDK.Model
{
    /// <summary>
    /// 用户 Model，用来表示微博用户的对象.
    /// </summary>
    public class User : BaseModel
    {
        private string name = string.Empty;
        private List<Tag> tag = null;
        private int isvip = 0;
        private int isidol = 0;
        private int idolnum = 0;
        private int fansnum = 0;
        private string location = string.Empty;
        private string openid = string.Empty;
        private string nick = string.Empty;
        private string introduction = string.Empty;
        private string verifyinfo = string.Empty;
        private string email = string.Empty;
        private int sex;


        /// <summary>
        /// 构造函数
        /// </summary>
        public User()
        { }

        /// <summary>
        /// 获取或设置用户帐户名.
        /// </summary>
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                if (value != name)
                {
                    name = value;
                    NotifyPropertyChanged("Name");
                }
            }
        }

        /// <summary>
        /// 获取或设置用户昵称.
        /// </summary>
        public string Nick
        {
            get
            {
                return nick;
            }
            set
            {
                if (value != nick)
                {
                    nick = value;
                    NotifyPropertyChanged("Nick");
                }
            }
        }

        /// <summary>
        /// 获取或设置用户唯一id，与name相对应.
        /// </summary>
        public string OpenId
        {
            get
            {
                return openid;
            }
            set
            {
                if (value != openid)
                {
                    openid = value;
                    NotifyPropertyChanged("OpenId");
                }
            }
        }

        /// <summary>
        /// 获取或设置所在地.
        /// </summary>
        public string Location
        {
            get
            {
                return location;
            }
            set
            {
                if (value != location)
                {
                    location = value;
                    NotifyPropertyChanged("Location");
                }
            }
        }

        private string isent = string.Empty;
        /// <summary>
        /// 获取或设置是否企业机构.
        /// </summary>
        public string IsEnt
        {
            get
            {
                return isent;
            }
            set
            {
                if (value != isent)
                {
                    isent = value;
                    NotifyPropertyChanged("IsEnt");
                }
            }
        }

        /// <summary>
        /// 获取或设置是否认证用户.
        /// </summary>
        public int IsVIP
        {
            get
            {
                return isvip;
            }
            set
            {
                if (value != isvip)
                {
                    isvip = value;
                    NotifyPropertyChanged("IsVIP");
                }
            }
        }
        
        /// <summary>
        /// 获取或设置听众数.
        /// </summary>
        public int FansNum
        {
            get
            {
                return fansnum;
            }
            set
            {
                if (value != fansnum)
                {
                    fansnum = value;
                    NotifyPropertyChanged("FansNum");
                }
            }
        }

        /// <summary>
        /// 获取或设置收听的人数.
        /// </summary>
        public int IdolNum
        {
            get
            {
                return idolnum;
            }
            set
            {
                if (value != idolnum)
                {
                    idolnum = value;
                    NotifyPropertyChanged("IdolNum");
                }
            }
        }
        
        /// <summary>
        /// 获取或设置是否我收听的人.
        /// </summary>
        public int Isidol
        {
            get
            {
                return isidol;
            }
            set
            {
                if (value != isidol)
                {
                    isidol = value;
                    NotifyPropertyChanged("Isidol");
                }
            }
        }

        
        /// <summary>
        /// 获取或设置个人介绍.
        /// </summary>
        public string Instroduction
        {
            get
            {
                return introduction;
            }
            set
            {
                if (value != introduction)
                {
                    introduction = value;
                    NotifyPropertyChanged("Instroduction");
                }
            }
        }

        
        /// <summary>
        /// 获取或设置认证信息.
        /// </summary>
        public string VerifyInfo
        {
            get
            {
                return verifyinfo;
            }
            set
            {
                if (value != verifyinfo)
                {
                    verifyinfo = value;
                    NotifyPropertyChanged("VerifyInfo");
                }
            }
        }

        
        /// <summary>
        /// 获取或设置邮箱.
        /// </summary>
        public string Email
        {
            get {
                return email;
            }
            set {
                if (value != email)
                {
                    email = value;
                    NotifyPropertyChanged("Email");
                }
            }
        }

        
        /// <summary>
        /// 获取或设置用户性别，1-男，2-女，0-未填写.
        /// </summary>
        private int Sex
        {
            get {
                return sex;
            }
            set {
                if (value != sex)
                {
                    sex = value;
                    NotifyPropertyChanged("Sex");
                }
            }
        }
        
        /// <summary>
        /// 获取或设置用户标签.
        /// </summary>
        public List<Tag> Tags
        {
            get
            {
                return tag;
            }
            set
            {
                if (value != tag)
                {
                    tag = value;
                    NotifyPropertyChanged("IsVIP");
                }
            }
        }
    }
}
