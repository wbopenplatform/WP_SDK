﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using TencentWeiboSDK.Services.Util;
using System.Runtime.Serialization;
using TencentWeiboSDK.Util;

namespace TencentWeiboSDK.Model
{
    /// <summary>
    /// Access Token 和 Request Token 的基类.
    /// </summary>
    public abstract class Token
    {
        /// <summary>
        /// 构造函数.
        /// </summary>
        /// <param name="content">回调的字符串.</param>
        internal Token(string content)
        {
            var result = OAuthHelper.GetQueryParameters(content);

            // 通过content, 初始化 Key 和 Secret
            this.TokenKey = result["oauth_token"];
            this.TokenSecret = result["oauth_token_secret"];
        }

        /// <summary>
        /// 构造函数，用于反序列化.
        /// </summary>
        public Token()
        { }

        /// <summary>
        /// 获取或设置 Toekn 的 Key.
        /// </summary>
        public virtual string TokenKey { get; set; }

        /// <summary>
        /// 获取或设置 Toekn 的 Secret.
        /// </summary>
        public virtual string TokenSecret { get; set; }
    }

    /// <summary>
    /// Request Toekn 类，用于表示服务器所返回的 Request Token 对象.
    /// </summary>
    public class RequestToken : Token
    {
        /// <summary>
        /// 构造函数.
        /// </summary>
        /// <param name="content">请求 Request Token 后, 服务器返回的结果.</param>
        public RequestToken(string content)
            : base(content)
        {
            this.AccessUrl = BuildAccessUri(TokenKey);
        }

        private string BuildAccessUri(string key)
        {
            return string.Format(@"https://open.t.qq.com/cgi-bin/authorize?oauth_token={0}", key);
        }

        /// <summary>
        /// 获取或设置验证码.
        /// </summary>
        public string Verifier { get; set; }

        /// <summary>
        /// 获取或设置请求用户授址地址.
        /// </summary>
        public string AccessUrl { get; set; }
    }

    /// <summary>
    /// Access Toekn 类，用于表示服务器所返回的 Access Token 对象.
    /// </summary>
    public class AccessToken : Token
    {
        /// <summary>
        /// 构造函数.
        /// </summary>
        public AccessToken()
        { }
        
        /// <summary>
        /// 构造函数.
        /// </summary>
        /// <param name="content">请求 Access Token 后, 服务器返回的结果.</param>
        public AccessToken(string content)
            : base(content)
        { 
        }
    }
}
