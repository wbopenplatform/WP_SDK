namespace TencentWeiboSDK.Hammock.Retries
{
    public interface IRetryCustomCondition
    {

    }
}