namespace TencentWeiboSDK.Hammock.Attributes
{
    internal interface INamedAttribute
    {
        string Name { get; }
    }
}