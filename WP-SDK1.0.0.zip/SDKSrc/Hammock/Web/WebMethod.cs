namespace TencentWeiboSDK.Hammock.Web
{
    public enum WebMethod
    {
        Get,
        Post,
        Delete,
        Put,
        Head,
        Options
    }
}