namespace TencentWeiboSDK.Hammock.Web
{
    internal class Triplet<TFirst, TSecond, TThird>
    {
        public TFirst First { get; set; }
        public TSecond Second { get; set; }
        public TThird Third { get; set; }
    }
}