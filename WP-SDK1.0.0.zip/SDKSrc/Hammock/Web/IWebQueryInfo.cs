namespace TencentWeiboSDK.Hammock.Web
{
    public interface IWebQueryInfo
    {

    }
}