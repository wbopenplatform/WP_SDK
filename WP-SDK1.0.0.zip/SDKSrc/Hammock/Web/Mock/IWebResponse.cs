namespace TencentWeiboSDK.Hammock.Web.Mocks
{
    public interface IWebResponse
    {
        string Response { get; }
    }
}