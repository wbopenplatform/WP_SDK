namespace TencentWeiboSDK.Hammock.Web.Mocks
{
    public interface IMockable
    {

    }
}