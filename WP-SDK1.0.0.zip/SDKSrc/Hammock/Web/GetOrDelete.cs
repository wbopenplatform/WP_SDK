﻿namespace TencentWeiboSDK.Hammock.Web
{
    public enum GetDeleteHeadOptions
    {
        Get,
        Delete,
        Head,
        Options
    }
}