namespace TencentWeiboSDK.Hammock.Web
{
    public delegate void WebCallback(object sender, WebQueryResponseEventArgs e);
}