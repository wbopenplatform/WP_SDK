﻿namespace TencentWeiboSDK.Hammock.Web
{
    public enum PostOrPut
    {
        Post,
        Put
    }
}