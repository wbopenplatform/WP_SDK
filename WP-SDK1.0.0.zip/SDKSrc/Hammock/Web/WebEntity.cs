using System.Text;

namespace TencentWeiboSDK.Hammock.Web
{
    public class WebEntity
    {
        public string Content { get; set; }
        public string ContentType { get; set; }
        public Encoding ContentEncoding { get; set; }
    }
}