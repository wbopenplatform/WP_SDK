﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using TencentWeiboSDK.Model;

namespace TencentWeiboSDK.Deserializer.Json
{
    /// <summary>
    /// Json 格式的用户(User)对象的反序列化器. 
    /// </summary>
    public class UserDeserializer : BaseDeserializer
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public UserDeserializer()
        { }
        
        /// <summary>
        /// 将用户(User)的 Json 字符串反序列化成 User 对象.
        /// </summary>
        /// <param name="content">需要反符列化的Json字符串</param>
        /// <returns>返回 User 对象</returns>
        public override Model.BaseModel Read(string content)
        {
            var jo = JObject.Parse(content)["data"];

            return jo.ToObject<User>();
        }

        /// <summary>
        /// 将用户(User)的 Json 字符串反序列成 User 对象列表.
        /// </summary>
        /// <param name="content">需要读取的Json字符串.</param>
        /// <returns>返回 User 的列表对象.</returns>
        public override IList ReadList(string content)
        {
            var jo = JObject.Parse(content);
            var jInfo = jo["data"]["info"];
            List<User> list = new List<User>();

            foreach (var j in jInfo.Children())
            {
                list.Add(j.ToObject<User>());
            }

            return list;
        }
    }
}
