﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TencentWeiboSDK.Model;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace TencentWeiboSDK.Deserializer.Json
{
    /// <summary>
    /// Json 格式的微博(Status)对象的反序列化器.
    /// </summary>
    public class StatusDeserializer : BaseDeserializer
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public StatusDeserializer()
        { }
        
        /// <summary>
        /// 将微博(Status)的 Json 字符串反序列化成 Status 对象.
        /// </summary>
        /// <param name="content">需要反符列化的Json字符串</param>
        /// <returns>返回 Status 对象</returns>
        public override BaseModel Read(string content)
        {
            var jo = JObject.Parse(content)["data"];
            return jo.ToObject<Status>();
        }

        /// <summary>
        /// 将微博(Status)的 Json 字符串反序列成 Status 对象列表.
        /// </summary>
        /// <param name="content">需要读取的Json字符串</param>
        /// <returns>返回 StatusCollection 对象</returns>
        public override IList ReadList(string content)
        {
            var jo = JObject.Parse(content);
            var jInfo = jo["data"]["info"];
            StatusCollection list = new StatusCollection();
            
            foreach (var j in jInfo.Children())
            {
                list.Add(j.ToObject<Status>());
            }

            var jUser = jo["data"]["user"];
            if (null != jUser) 
            {
                foreach (JProperty u in jUser.Children())
                {
                    list.Users.Add(new User() { Name = u.Name, Nick = u.Value.ToString() });
                }
            }

            return list;
        }
    }
}
