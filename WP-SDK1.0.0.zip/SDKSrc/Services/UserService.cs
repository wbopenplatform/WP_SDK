﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TencentWeiboSDK.Services.Util;
using TencentWeiboSDK.Model;
using TencentWeiboSDK.Deserializer;

namespace TencentWeiboSDK.Services
{
    /// <summary>
    /// UserService 包含了帐户相关 API.
    /// </summary>
    public class UserService : BaseService
    {

        /// <summary>
        /// 构造函数.
        /// </summary>
        public UserService()
            : this(null)
        { }

        /// <summary>
        /// 构造函数.
        /// </summary>
        /// <param name="accessToken">
        /// 指示该 Service 所需要的 AccessToken，优先级高于 OAuthConfigruation.AccessToken, 若该值为 null,
        /// SDK 将默认使用 OAuthConfigruation.AccessToken.
        /// </param>
        public UserService(AccessToken accessToken)
            : base(accessToken)
        { }


        /// <summary>
        /// 获取自己的详细资料.
        /// </summary>
        /// <param name="callback">回调返回 User 对象.</param>
        public void UserInfo(Action<Callback<User>> callback)
        {
            this.Get("user/info", new ServiceArgument(), (request, response, userState) =>
            {
                if (null != callback)
                {
                    User user = null;
                    BaseDeserializer serializer = DeserializerManager.Instance.BuildUserDeserializer();
                    user = serializer.Read(response.Content) as User;

                    if (null != callback)
                    {
                        callback(new Callback<User>(user));
                    }
                }
            });
        }
    }
}
