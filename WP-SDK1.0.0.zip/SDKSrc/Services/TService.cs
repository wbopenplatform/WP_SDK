﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TencentWeiboSDK.Services.Util;
using TencentWeiboSDK.Model;

namespace TencentWeiboSDK.Services
{
    /// <summary>
    /// TService 包含了微博相关 API.
    /// </summary>
    public sealed class TService : BaseService
    {
        /// <summary>
        /// 构造函数.
        /// </summary>
        public TService()
            : this(null)
        { }

        /// <summary>
        /// 构造函数.
        /// </summary>
        /// <param name="accessToken">
        /// 指示该 Service 所需要的 AccessToken，优先级高于 OAuthConfigruation.AccessToken, 若该值为 null,
        /// SDK 将默认使用 OAuthConfigruation.AccessToken.
        /// </param>
        public TService(AccessToken accessToken)
            : base(accessToken)
        { }
        
        /// <summary>
        /// 发表一条微博.
        /// </summary>
        /// <param name="argment">参数列表, Content为必填参数</param>
        /// <param name="callback">无返回数据</param>
        public void Add(ServiceArgument argment, Action<Callback<object>> callback)
        {
            this.Post("t/add", argment, (request, response, userState) =>
            {
                if (null != callback)
                {
                    callback(new Callback<object>(null));
                }
            });
        }

        /// <summary>
        /// 发表一条带图片的微博.
        /// </summary>
        /// <param name="argment">参数列表，Content和UploadPic为必填参数.</param>
        /// <param name="callback">无返回数据.</param>
        public void AddPic(ServiceArgument argment, Action<Callback<object>> callback)
        {
            this.Post("t/add_pic", argment, (request, response, userState) =>
            {
                if (null != callback)
                {
                    callback(new Callback<object>(null));
                }
            });
        }
    }
}
