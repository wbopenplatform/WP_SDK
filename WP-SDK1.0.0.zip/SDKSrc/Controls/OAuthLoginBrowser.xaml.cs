﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TencentWeiboSDK.Model;
using TencentWeiboSDK.Services.Util;
using System.IO.IsolatedStorage;
using TencentWeiboSDK.Services;
using TencentWeiboSDK.Util;

namespace TencentWeiboSDK.Controls
{
    /// <summary>
    /// OAuth 登录控件，用于 OAuth 授权，并返回 AccessToken 对象.
    /// </summary>
    public partial class OAuthLoginBrowser : UserControl
    {  
        private OAuthService service = new OAuthService();
        private const string callbackUrl = "http://t.qq.com";
        private RequestToken requestToken = null;
        private Action<Callback<AccessToken>> actionTokenCallback = null;

        /// <summary>
        /// 构造函数.
        /// </summary>
        public OAuthLoginBrowser()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 开始进行 OAuth 授权，若用户授权成功，则返回 AccessToken.
        /// </summary>
        /// <param name="actionTokenCallback">回调返回 AccessToken.</param>
        public void OAuthLogin(Action<Callback<AccessToken>> actionTokenCallback)
        {
            this.actionTokenCallback = actionTokenCallback;
            
            if (string.IsNullOrEmpty(OAuthConfigruation.APP_KEY))
            {
                MessageBox.Show("请输入ConsumerKey!");

                OnCallbackAccessToken(null);
                return;
            }

            if (string.IsNullOrEmpty(OAuthConfigruation.APP_SECRET))
            {
                MessageBox.Show("请输入ConsumerSecret!");

                OnCallbackAccessToken(null);
                return;
            }

            service.GetRequestTokenRequest(callbackUrl, (action) =>
            {
                this.requestToken = action.Data;

                this.Dispatcher.BeginInvoke(() =>
                {
                    webBrowser1.Navigate(new Uri(requestToken.AccessUrl));
                });
            });
        }

        

        private void webBrowser1_Navigating(object sender, Microsoft.Phone.Controls.NavigatingEventArgs e)
        {
            if (e.Uri.ToString().StartsWith(callbackUrl))
            {
                e.Cancel = true;
                var result = OAuthHelper.GetQueryParameters(e.Uri.ToString());
                requestToken.Verifier = result["oauth_verifier"];

                service.GetAccessTokenRequest(requestToken, (callback) =>
                {
                    if (OAuthConfigruation.IfSaveAccessToken)
                    {
                        OAuthConfigruation.AccessToken = callback.Data;
                        TokenIso.Current.SaveData(callback.Data);
                    }

                    this.Dispatcher.BeginInvoke(() =>
                    {
                        if (actionTokenCallback != null)
                        {
                            actionTokenCallback(callback);
                        }
                    });
                });
            }
        }

        private void UserControl_SizeChanged_1(object sender, SizeChangedEventArgs e)
        {
            webBrowser1.Width = this.Width;
            webBrowser1.Height = this.Height;
        }

        private void OnCallbackAccessToken(AccessToken accessToken)
        {
            this.Dispatcher.BeginInvoke(() =>
                {
                    if (null != this.actionTokenCallback)
                    {
                        actionTokenCallback(new Callback<AccessToken>(accessToken != null, accessToken));
                    }
                });
        }

    }
}
