﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using TencentWeiboSample.ViewModel;

namespace TencentWeiboSample
{
    public partial class TimelineView : PhoneApplicationPage
    {
        private TimelineViewModel vm = new TimelineViewModel();
        
        public TimelineView()
        {
            InitializeComponent();

            //将TimelineViewModel绑定到UI
            this.DataContext = vm;
        }

        private void Refresh()
        {
            vm.Refresh(null);
        }

        private void ApplicationBarIconButton_Click(object sender, EventArgs e)
        {
            Refresh();
        }

        private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
        {
            Refresh();
        }

        private void postNewButton_Click(object sender, EventArgs e)
        {
            //打开发送微博页面
            NavigationService.Navigate(new Uri("/PostNewWeiboView.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}