﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using TencentWeiboSample.ViewModel;

namespace TencentWeiboSample
{
    public partial class PostNewWeiboView : PhoneApplicationPage
    {
        //实例化ViewModel
        private PostNewViewModel vm = new PostNewViewModel();
        
        public PostNewWeiboView()
        {
            InitializeComponent();

            //将ViewModel绑定到UI
            this.DataContext = vm;
        }

        private void ApplicationBarIconButton_Click(object sender, EventArgs e)
        {
            vm.Text = textBox1.Text;
            //发送微博，在这里可以提示用户正在发送，或者切换回上一个页面
            vm.Post(() =>
                { 
                    //回调回来后可以通知用户已经发送成功或失败
                });
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            //打开Gallery，选择图片
            vm.ChoosePic();
        }
    }
}