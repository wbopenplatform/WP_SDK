﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using TencentWeiboSDK.Model;
using TencentWeiboSDK.Services;
using TencentWeiboSDK.Services.Util;

namespace TencentWeiboSample.ViewModel
{
    public class TimelineViewModel : BaseViewModel
    {
        /// <summary>
        /// 实例化时间线相关 API 服务.
        /// </summary>
        private StatusesService statusService = new StatusesService();

        /// <summary>
        /// 实例化帐户相关 API 服务.
        /// </summary>
        private UserService userService = new UserService();
        private User user;
        
        /// <summary>
        /// 构造函数
        /// </summary>
        public TimelineViewModel()
        {
            Timeline = new ObservableCollection<Status>();
        }

        /// <summary>
        /// 刷新Timeline View所需要的数据
        /// </summary>
        /// <param name="action">刷新完成后，回调到UI线程 /param>
        public void Refresh(Action action)
        {
            // 异步刷新可以让用户有更好的操作体验
            new Thread(() =>
                {
                    // 获得自己的详细资料.
                    userService.UserInfo((userCallback) =>
                    {
                        // Callback 结果是当前 AccessToken 的用户数据
                        // 可以参考 UserInfo 的定义: UserInfo(Action<Callback<User>> callback)
                        this.User = userCallback.Data;

                        // 刷新Timeline, API的参数是通过ServiceArugment传递，只需要填入你所需要的参数
                        // 同样，callback的数据类型为: StatusCollection, 参考该API的定义： 
                        // HomeTimeline(ServiceArgument argment, Action<Callback<StatusCollection>> callback);
                        statusService.HomeTimeline(new ServiceArgument() { Reqnum = 30 }, (callback) =>
                        {
                            // 因为回调回来之后会是后台线程，需要切换到UI线程去处理ObservableCollection
                            // 相关的操作
                            Deployment.Current.Dispatcher.BeginInvoke(() =>
                            {
                                // 清空Timeline，并把回调回来的数据添加到Timeline里去.
                                Timeline.Clear();
                                callback.Data.ForEach(a => Timeline.Add(a));

                                // 切换并回调到UI线程.
                                Deployment.Current.Dispatcher.BeginInvoke(() =>
                                    {
                                        if (null != action)
                                        {
                                            action();
                                        }
                                    });
                            });
                        });
                    });
                }).Start();
        }

        
        
        /// <summary>
        /// 获取或设置当前登陆用户
        /// </summary>
        public User User
        {
            get { return user; }
            set
            {
                if (user != value)
                {
                    user = value;
                    NotifyPropertyChanged("User");
                }
            }
        }

        /// <summary>
        /// 获取或设置首页时间线
        /// </summary>
        public ObservableCollection<Status> Timeline
        {
            get;
            set;
        }
    }
}
